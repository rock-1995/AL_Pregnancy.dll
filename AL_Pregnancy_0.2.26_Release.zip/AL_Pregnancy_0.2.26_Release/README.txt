AL Pregnancy 0.2.26

This release only updates names and English-language text. Gameplay, physics, shape settings, defaults, and save formats are unchanged from 0.2.25.

INSTALL / UPGRADE
1. Close AmanatsuLocation and back up the existing plugin.
2. Remove AL_Pregnancy.Preview.dll from the BepInEx/plugins tree when upgrading. Keep only one version installed.
3. Place AL_Pregnancy.dll in BepInEx/plugins/AL_Pregnancy/.
4. Keep the existing configuration and saves. No reset or migration is required.

The old AL_PregnancyPreview folder may be renamed to AL_Pregnancy to preserve its diagnostics. New captures use AL_Pregnancy/diagnostics/latest-mesh.json.
The legacy internal ID and configuration filename local.al.pregnancy.preview.cfg remain for compatibility. The plugin's release name is AL Pregnancy.
F8 manual shape-preview controls remain available; "preview" there describes a feature rather than release status.

F1: global settings (requires the game's configuration manager).
F8: character panel and manual shape preview.

Full English source and build instructions: AL_Pregnancy_0.2.26_Source.zip.
